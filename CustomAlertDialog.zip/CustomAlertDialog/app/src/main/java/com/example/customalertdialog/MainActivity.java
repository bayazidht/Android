package com.example.customalertdialog;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void customAlertDialog(View v) {
        LayoutInflater inflater = getLayoutInflater();
        View customView = inflater.inflate(R.layout.layout_custom_alert_dialog, (ViewGroup) findViewById(R.id.custom_alert_dialog_view));

        final AlertDialog customDialog = new AlertDialog.Builder(this).create();
        customDialog.setView(customView);
        customView.findViewById(R.id.btnYes).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Yes button clicked!", Toast.LENGTH_SHORT).show();
                customDialog.dismiss();
            }
        });
        customView.findViewById(R.id.btnNo).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "No button clicked!", Toast.LENGTH_SHORT).show();
                customDialog.dismiss();
            }
        });
        customDialog.show();
    }
}